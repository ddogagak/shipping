create sequence if not exists public.stock_sku_seq start 1;

create table if not exists public.stock_category (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.stock_category (code, name, sort_order) values
  ('skz','SKZ',1),('figure','피규어',2),('gacha','가챠',3),('random_goods','랜덤굿즈',4),('etc','기타',99)
on conflict (code) do update set name = excluded.name, sort_order = excluded.sort_order;

create table if not exists public.stock_location (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.stock_location (name, sort_order) values ('미지정',0)
on conflict (name) do nothing;

create table if not exists public.stock_batch (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  purchased_at date,
  source text,
  memo text,
  created_at timestamptz not null default now()
);

create table if not exists public.stock_product (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique default ('ST-' || lpad(nextval('public.stock_sku_seq')::text, 6, '0')),
  category_id uuid references public.stock_category(id),
  batch_id uuid references public.stock_batch(id) on delete set null,
  title text not null,
  collection_name text,
  folder_name text,
  release_name text,
  item_type text,
  release_price numeric(12,2),
  desired_price numeric(12,2),
  currency text not null default 'KRW',
  primary_image_url text,
  memo text,
  status text not null default 'active' check (status in ('active','reserved','sold_out','hold','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.stock_variant (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.stock_product(id) on delete cascade,
  variant_name text not null,
  variant_code text not null,
  member_name text,
  character_name text,
  version_name text,
  image_url text,
  desired_price numeric(12,2),
  memo text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(product_id, variant_code)
);

create table if not exists public.stock_quantity (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references public.stock_variant(id) on delete cascade,
  location_id uuid not null references public.stock_location(id),
  quantity integer not null default 0 check (quantity >= 0),
  updated_at timestamptz not null default now(),
  unique(variant_id, location_id)
);

create table if not exists public.stock_history (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references public.stock_variant(id) on delete cascade,
  location_id uuid references public.stock_location(id),
  action text not null check (action in ('initial','in','out','move_in','move_out','adjust')),
  quantity_change integer not null,
  quantity_after integer,
  reason text,
  created_at timestamptz not null default now()
);

create table if not exists public.stock_variant_dictionary (
  id uuid primary key default gen_random_uuid(),
  dictionary_type text not null,
  display_name text not null,
  alias text not null,
  code text not null,
  created_at timestamptz not null default now(),
  unique(dictionary_type, alias)
);

insert into public.stock_variant_dictionary(dictionary_type,display_name,alias,code) values
('member','방찬','방찬','CHAN'),('member','방찬','Bang Chan','CHAN'),
('member','리노','리노','KNOW'),('member','리노','Lee Know','KNOW'),
('member','창빈','창빈','CBIN'),('member','창빈','Changbin','CBIN'),
('member','현진','현진','HJIN'),('member','현진','Hyunjin','HJIN'),
('member','한','한','HAN'),('member','한','Han','HAN'),
('member','필릭스','필릭스','FLIX'),('member','필릭스','Felix','FLIX'),
('member','승민','승민','SMIN'),('member','승민','Seungmin','SMIN'),
('member','아이엔','아이엔','IN'),('member','아이엔','I.N','IN')
on conflict (dictionary_type, alias) do update set display_name=excluded.display_name, code=excluded.code;

create index if not exists idx_stock_product_category on public.stock_product(category_id);
create index if not exists idx_stock_variant_product on public.stock_variant(product_id);
create index if not exists idx_stock_quantity_variant on public.stock_quantity(variant_id);
